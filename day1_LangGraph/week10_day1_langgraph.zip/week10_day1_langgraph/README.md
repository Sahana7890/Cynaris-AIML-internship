# Week 10 Day 1 — LangGraph Stateful Agent Graph

## Objective
Build a LangGraph graph with classification, routing, response generation, and human-in-the-loop interruption.

## Graph
START → classify → route → respond → human_review → END

## Features
- Stateful graph using `TypedDict`
- Classification into `technical`, `billing`, and `general`
- Conditional edge based on classification
- Human-in-the-loop using `interrupt()`
- Resume using `Command(resume=...)`
- `MemorySaver` checkpointing
- Five test inputs

## Installation

```bash
pip install -r requirements.txt
```

## Run

```bash
python app.py
```

For each test, enter:

```text
yes
```

or

```text
no
```

when the graph pauses.

## Test cases

1. My laptop is not working → technical
2. I need a refund for my payment → billing
3. Hello, how are you? → general
4. The application crashes when I open it → technical
5. What is the price of the service? → billing

## Git commit

```bash
git add .
git commit -m "feat: langgraph — stateful agent graph with routing"
git push
```
