# MedScan Diagnostics — Data Exploration
# Run this as a Python script or copy the cells into a Jupyter notebook.

from pathlib import Path
import pandas as pd
import matplotlib.pyplot as plt
from PIL import Image

ROOT = Path.cwd().parent if Path.cwd().name == "notebooks" else Path.cwd()
RAW = ROOT / "data" / "raw"

classes = ["normal", "pneumonia", "covid"]

counts = {}
for cls in classes:
    folder = RAW / cls
    counts[cls] = sum(
        1 for p in folder.rglob("*")
        if p.is_file() and p.suffix.lower() in {".jpg", ".jpeg", ".png", ".bmp", ".webp"}
    )

print("Class counts:")
print(counts)

if sum(counts.values()) == 0:
    print("\nNo X-ray images found yet. Add an approved dataset under data/raw/.")
else:
    plt.figure(figsize=(7, 4))
    plt.bar(counts.keys(), counts.values())
    plt.title("Class Distribution")
    plt.xlabel("Class")
    plt.ylabel("Number of Images")
    plt.tight_layout()
    plt.show()

    # Display one sample from each class.
    fig, axes = plt.subplots(1, 3, figsize=(12, 4))
    for ax, cls in zip(axes, classes):
        folder = RAW / cls
        candidates = [
            p for p in folder.rglob("*")
            if p.is_file() and p.suffix.lower() in {".jpg", ".jpeg", ".png", ".bmp", ".webp"}
        ]
        if candidates:
            img = Image.open(candidates[0]).convert("RGB")
            ax.imshow(img)
            ax.set_title(cls)
        else:
            ax.set_title(f"{cls}: no image")
        ax.axis("off")
    plt.tight_layout()
    plt.show()
