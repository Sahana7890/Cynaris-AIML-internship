# MedScan Diagnostics — Baseline Report

## 1. Objective

Build a three-class chest X-ray classifier for Normal, Pneumonia, and COVID-19 using transfer learning with ResNet-18.

## 2. Dataset

**Status:** Client-provided 3,000-image dataset is not currently available in this working repository.

No dataset counts or performance values are fabricated in this report. Once an approved dataset is obtained, record:

| Item | Value |
|---|---|
| Dataset source | TBD |
| Total images | TBD |
| Normal | TBD |
| Pneumonia | TBD |
| COVID-19 | TBD |
| Train | TBD |
| Validation | TBD |
| Test | TBD |

## 3. Data ingestion

The pipeline scans the three class directories:

- `data/raw/normal/`
- `data/raw/pneumonia/`
- `data/raw/covid/`

Supported image formats are JPEG, PNG, BMP, and WebP.

The ingestion script produces a stratified train/validation/test split and stores the split manifests in `data/splits/`.

## 4. Preprocessing

- Resize to 224 × 224.
- Convert images to RGB.
- Convert to PyTorch tensors.
- Normalize using ImageNet mean and standard deviation.
- Training augmentation: horizontal flip and small rotation.
- Validation/test data are not randomly augmented.

## 5. Baseline model

- Architecture: ResNet-18.
- Initial weights: ImageNet pretrained weights.
- Final fully connected layer replaced with a 3-class output layer.
- Loss: Cross-Entropy Loss.
- Optimizer: AdamW.

## 6. Evaluation benchmark

The test benchmark will report:

- Accuracy
- Per-class precision
- Per-class recall
- Per-class F1
- Macro ROC-AUC using one-vs-rest
- Confusion matrix
- COVID-19 false-negative rate

COVID-19 FNR is:

`FN / (TP + FN)`

The project acceptance target is FNR < 0.15.

## 7. Results

**Pending approved dataset and baseline training.**

Do not replace this section with invented numbers.

## 8. Limitations

This baseline is a research/internship prototype and is not a clinical diagnostic device. Performance may be affected by dataset size, class imbalance, acquisition differences, population differences, label quality, and distribution shift.

The eventual model card should document dataset provenance, intended use, limitations, and evaluation conditions.
