# Reference Data

Place the internship-provided reference files here.

Expected files:
- aiml_healthcare_symptoms.csv
- aiml_healthcare_test_cases.txt
- aiml_labelled_samples.json

These files are separate from the chest X-ray image dataset.
