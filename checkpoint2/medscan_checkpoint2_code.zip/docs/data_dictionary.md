# Data Dictionary

## Split manifest

| Column | Description |
|---|---|
| image_path | Image path relative to `data/raw/` |
| label | Human-readable class: normal, pneumonia, or covid |
| label_id | Integer class index: normal=0, pneumonia=1, covid=2 |

## Dataset requirements

Images should be stored under:

```text
data/raw/
├── normal/
├── pneumonia/
└── covid/
```

Only an approved dataset should be used for the final internship results.
