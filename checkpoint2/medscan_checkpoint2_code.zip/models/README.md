# Model Artifacts

Trained model weights are generated here.

The repository `.gitignore` excludes `.pth` and `.pt` files by default. Do not commit large model artifacts unless the internship submission instructions require it and the repository/storage policy permits it.
