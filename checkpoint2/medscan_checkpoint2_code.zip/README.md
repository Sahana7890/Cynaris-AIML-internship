# MedScan Diagnostics — Checkpoint 2

Chest X-ray 3-class classification pipeline using PyTorch and pretrained ResNet-18.

Classes:
- normal
- pneumonia
- covid

## Important
The client-provided 3,000-image dataset was not included in the current project files. This repository therefore contains the reproducible ingestion, preprocessing, training, and evaluation pipeline, but **does not contain fabricated data or results**.

Place an approved dataset in:
`data/raw/normal/`
`data/raw/pneumonia/`
`data/raw/covid/`

Then run the pipeline described below.

## Setup

```bash
python -m venv .venv
# Windows PowerShell
.venv\Scripts\Activate.ps1

pip install -r requirements.txt
```

## Run

```bash
python -m src.dataset
python -m src.train
python -m src.evaluate
```

Generated split files go to `data/splits/`; figures go to `reports/figures/`; model weights go to `models/`.

Do not commit patient-sensitive data or restricted datasets to GitHub. Follow the dataset license and internship/client instructions.
